# CS336-Group-108-Project

CS 336 Final Project:

Division of Work:
Part 1- ALL <br />
Part 2- Anis Chihoub <br /> 
Part 3- Stanley Chou <br /> 
Part 4- Irfan Peer <br />
Part 5- Dhvani Kakabalia <br /> 



Admin Login: <br />
Username: Miranda <br />
password: 123 <br />

Representative Login: <br />
Username: Dhvani <br />
password: 123 <br />
